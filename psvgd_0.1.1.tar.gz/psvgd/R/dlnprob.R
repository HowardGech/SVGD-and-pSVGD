#' gradient of lnpdf of gauss(normal) distribution especially high dimension
#'
#' @param A identity matrix or an initial defined matrix
#' @param mu the posterior samples, which contributes vital information to each step of iteration(the distribution family contributes the distribution, and mu contributes to posterior parameter)
#'
#' @return matrix(jaccobi) of lnpdf of normal distribution
#' @export
#'
dlnprob=function(mu,theta,A=diag(rep(1,ncol(x0)))){
  m=matrix(0,nrow=nrow(theta),ncol=ncol(theta))
  s=matrix(nrow=nrow(theta),ncol=ncol(theta))
  for(j in 1:nrow(mu)){
    for(i in 1:nrow(theta)){
      s[i,]=mu[j,]
    }
    m=m+s
  }
  return(-(nrow(mu)*theta-m)%*%A)
}
