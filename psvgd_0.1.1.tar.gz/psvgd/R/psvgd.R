#' Projected Stein Variational Gradient Descent
#'
#' @description easy to say: contains svgd as each step, using projecting to decrease the dimension, greatly shorten the time use of algorithm
#' @param y the goal of the parameter(fixed)
#' @param x0 initial samples need to be sent to the goal distribution
#' @param phir the eigenvector got by decreasing dimension procedure in adpt.psvgd
#' @param lnprob the gradient of ln probability density (function name, function need to be defined by yourself or the high dimension gauss/normal distribution displayed here)
#' @param n_iter max iteration control
#' @param stepsize stepsize coltrol in each iteration
#' @param alpha calculation parameter
#' @param wtol convergence control
#'
#' @return sample(x0) after iteration
#'
psvgd=function(y,x0,phir,lnprob,n_iter=1000,stepsize=1e-3,alpha=0.9,wtol=1e-3){
  w0=x0%*%phir
  x_vert=x0-w0%*%t(phir)
  dln_pi=function(y,w) lnprob(y,w%*%t(phir)+x_vert)%*%phir
  wp=svgd(y,w0,dln_pi,n_iter=n_iter,stepsize=stepsize,bandwidth=bandwidtn,alpha=alpha,dtol=wtol)
  x=wp%*%t(phir)+x_vert
  return(x)
}
