#' @title a pushforward funcion
#'
#' @description  push forward a Brownian Motion into adifussion
#' @param z the increasement of Brownian Motion (increasement, instead of exact Brownian Motion)
#' @param M the dim of data, if defined from 0 to 1,del=0.01, dim is 100, with initial data in 0 is 0
#' @param del the delta parameter in each step in the  Euler-Maruyama scheme
#'
#' @return a pushforward data ut
#' @export
#'
#' @examples z=rnorm(100,0,0.1)
#' @examples ut=forward(z=z)
forward <- function(z,M = 100,del=0.01){  #ok
  ut <- vector(length = 100)
  ut[1] = z[1]
  for (i in 2:M) {  #ut initialization
    ut[i] = 10*ut[i-1]*(1-ut[i-1]^2)/(1+ut[i-1]^2)*del+z[i]+ut[i-1]
  }
  return(ut)
}
