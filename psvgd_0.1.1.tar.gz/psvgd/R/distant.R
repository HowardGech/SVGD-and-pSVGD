#' @title distant of samples
#' @description get the  norm of input matrix column(used in psvgd)
#'
#' @param theta (a matrix form of numbers)

#'
#' @return the distant of theta in psvgd augrithm
#' @export
#'
#' @examples
#' x = matrix(c(1,2,3,4),ncol=2)
#' distant(x1)
#' espacially essential when used in a minus of two matrix
distant=function(theta){
  dist=matrix(0,ncol = nrow(theta),nrow = nrow(theta))
  for(i in 1:nrow(theta)){
    for(j in i:nrow(theta)){
      dist[i,j]=sum((theta[i,]-theta[j,])^2)
      dist[j,i]=dist[i,j]
    }
  }
  return(dist)
}
